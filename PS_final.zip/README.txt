COMO USAR:

Abrir projeto na IDE;
Abrir o código da Interface;
Ir no código-fonte da Interface;
Mudar os caminhos para abrir arquivos:
	- file_out_macro;
	- file_out_montador;
	- file_out_ligador;
Executar a Interface;
Ir lá em cima no file e selecionar Codigo_1;
Apertar em arquivo_1 na Interface;
Ir lá em cima no file e selecionar Codigo_2;
Apertar em arquivo_2 na Interface;
Apertar o botão Executar;
Os botões Macro, Ligador e Montador mostra o que cada etapa gerou;
